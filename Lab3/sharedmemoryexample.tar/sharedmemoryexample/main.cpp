#include <iostream>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <mm.h>
#include <main.h>

using namespace std;

const int BUFFER_SIZE = 1000;
const char TICKER_SIZE = 4;

typedef struct {
  char   ticker[TICKER_SIZE];
  double price;
} item;


char* getTickerSymbol();
// Precondition: none
// Postcondition: returns a TICKER_SIZE character C-string the first 3 characters of which are random 
//                letters 'A'-'Z'.  The last character is '\0'.
// NOTE:          You must call free() to release the C-string returned when you are done with
//                it or you'll end up with a memory leak.

// This program demonstrates a solution to the producer consumer problem using a circular buffer
// and shared memory as the communication mechanism.  The description of the problem was taken
// from "Operating System Concepts: 6th Edition By Silbershatz, Galvin, Gagne".

int main(void)
{

  /////////////////////////////////////////////////////////////////////////////////
  // Shared Memory Initialization Stuff
  ///////////////////////////////////////////////////////////////////////////////
  char file[]="/tmp/sharedmemory";
 
 // Initialize shared memory to maximum allowable
  int result = MM_create(0,file); 
  if (result != 1) {
    cerr << "main: Unable to initialize shared memory." << endl;
    exit(-1);
  }

  // Carve out a CIRCULAR buffer from shared memory
  item* buffer = (item *) MM_malloc(BUFFER_SIZE*sizeof(item));

  // Carve out IN from shared memory
  // IN points to the next free position in the circular buffer
  // IN==OUT then buffer is EMPTY
  // ((IN+1) % BUFFER_SIZE) == OUT then buffer is FULL
  int *in = (int *) MM_malloc(sizeof(int));

  // Carve out OUT from shared memory
  // OUT points to the first position in the buffer that contains
  // unconsumed items.
  int *out = (int *) MM_malloc(sizeof(int));

  if ((buffer == NULL) || (in == NULL) || (out == NULL)) {
    cerr << "main: Unable to allocated shared memory." << endl;
    exit(-1);
  }

  
  // create a child
  int pid = fork();

  // Error forking
  if (pid < 0) {
    cerr << "main: Fork failed!" << endl;
    exit(-1);
  }

  /////////////////////////////////////////////////////////////////////
  // Child process is the CONSUMER
  /////////////////////////////////////////////////////////////////////
  if (pid ==0) {

    while (true) {
   
      // Busy wait for something in buffer
      while (*in == *out); 

      // Copy item out of buffer
      item nextConsumed;
      memcpy(nextConsumed.ticker,buffer[*out].ticker,TICKER_SIZE);
      nextConsumed.price = buffer[*out].price;
      
      // Move output buffer pointer ahead one
      *out = (*out + 1) % BUFFER_SIZE;

      // Output item
      cout << "child: " << nextConsumed.ticker << " " << nextConsumed.price << endl;

    }
  }

  /////////////////////////////////////////////////////////////////////
  // Parent process is the PRODUCER
  /////////////////////////////////////////////////////////////////////
  else {
    int count=0;

    while (true) {

      // Busy wait for room in the buffer
      while (((*in + 1) % BUFFER_SIZE) == *out);
      
      // Create item
      item nextProduced;
      char* freeme;
      memcpy(nextProduced.ticker,freeme=getTickerSymbol(),TICKER_SIZE);
      nextProduced.price = count;
      free(freeme);
      count++;

      // Copy item to buffer
      memcpy(buffer[*in].ticker,nextProduced.ticker,TICKER_SIZE);
      buffer[*in].price = nextProduced.price;

      // Move input buffer pointer ahead one
      *in = (*in + 1) % BUFFER_SIZE;

    }
  }

  return 1;
}

char* getTickerSymbol()
{
  static bool firstTime = true;

  if (firstTime) {
    firstTime = false;
    srand(time(0));
  }

  char* result =  new char[TICKER_SIZE];
  
  result[0]='A'+rand() % 26;
  result[1]='A'+rand() % 26;
  result[2]='A'+rand() % 26;
  result[3]='\0';

  return result;
}
